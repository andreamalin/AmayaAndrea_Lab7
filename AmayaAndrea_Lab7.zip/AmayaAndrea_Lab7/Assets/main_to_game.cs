﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class main_to_game : MonoBehaviour
{
    private AudioSource again;
    // Start is called before the first frame update
    void Start()
    {
        again = GetComponent<AudioSource>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void GameScene(int _sceneIndex)
    {
        SceneManager.LoadScene(_sceneIndex);
    }

    public void exit()
    {
        UnityEditor.EditorApplication.isPlaying = false;
    }
}
