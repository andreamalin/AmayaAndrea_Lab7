﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;


public class sphere_mov : MonoBehaviour
{
    private Rigidbody rb;
    public float velocidad = 0;
    public float jumpForce = 0;
    public float force = 0;

    private AudioSource audioManager;
    public AudioClip coin;
    public AudioClip wow;
    public AudioClip boing;
    public AudioClip suspense;

    private new_sphere player;
    private NavMeshAgent agent;
    private void Awake()
    {
        agent = GetComponent<NavMeshAgent>();
        player = FindObjectOfType<new_sphere>();
    }

    // Start is called before the first frame update
    void Start()
    {
        Time.timeScale = 1.0f;
        rb = GetComponent<Rigidbody>();
        audioManager = GetComponent<AudioSource>();
        audioManager.PlayOneShot(suspense);
    }

    // Update is called once per frame
    void Update()
    {

        transform.Translate(new Vector3(Input.GetAxis("Horizontal") * velocidad, 0,
            Input.GetAxis("Vertical") * velocidad) * Time.deltaTime, Space.World);

        

        if (Input.GetButtonDown("Jump"))
        {
            agent.enabled = false;
            Jump();
        }

        if (Input.GetMouseButton(0))
        {
            agent.enabled = true;
            Ray myRay = Camera.main.ScreenPointToRay(Input.mousePosition);
            RaycastHit hitInfo;

            if (Physics.Raycast(myRay, out hitInfo))
            {
                agent.SetDestination(hitInfo.point);
            }
        } if (Input.GetMouseButtonUp(0))
        {
            agent.enabled = false;
        }
        



    }

    private void FixedUpdate()
    {
        if (rb)
        {
            rb.AddForce(Input.GetAxis("Horizontal") * force, 0, Input.GetAxis("Vertical") * force);
        }
    }

    void Jump()
    {
        if (rb)
        {
            if (Mathf.Abs(rb.velocity.y) < 0.05f)
            {
                audioManager.PlayOneShot(boing);
                rb.AddForce(0, jumpForce, 0, ForceMode.Impulse);
            }
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        
        if (collision.gameObject.CompareTag("Coin"))
        {
            player.UpdateScore();
            audioManager.PlayOneShot(coin);
            Destroy(collision.gameObject);
        }

        if (collision.gameObject.CompareTag("Respawn")) { 
            if (player.getMonedas() < 3)
            {
                Destroy(gameObject);
            }
            else
            {
                audioManager.PlayOneShot(wow);
                Destroy(collision.gameObject);
            }

        }
    }





}
