﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;


public class new_sphere : MonoBehaviour
{
    public GameObject preFab;
    private GameObject sphere;
    public Text score;

    private int monedas = 0;

    public Slider slider;
    public AudioSource ambiental;

    public GameObject pauseMenu;
    private bool isPaused = false;

    

    // Start is called before the first frame update
    void Start()
    {
        
        Time.timeScale = 1.0f;
        sphere = Instantiate(preFab, new Vector3(3.83f, 0.35f, 3.89f), Quaternion.identity);
        ambiental.Play();
    }

    // Update is called once per frame
    void Update()
    {
        if (slider)
        {
            ambiental.volume = slider.value;
        }
        

        if (Input.GetButtonDown("Enter") && !sphere)
        {
            Time.timeScale = 1.0f;
            sphere = Instantiate(preFab, new Vector3(3.83f, 0.35f, 3.89f), Quaternion.identity);
        }

        if (Input.GetButtonDown("Cancel"))
        {
            onPause();
        }


    }

    public void onPause()
    {
        if (pauseMenu)
        {
            
            pauseMenu.SetActive(!pauseMenu.activeSelf);
            isPaused = !isPaused;
            Time.timeScale = isPaused ? 0.0f : 1.0f;

            if (Time.timeScale == 0)
            {
                ambiental.Pause();
            } else
            {
                ambiental.Play();
            }
            
        }

    }


    public void MainScene(int _sceneIndex)
    {
        SceneManager.LoadScene(_sceneIndex);
    }

    public void RestartScene()
    {
        
        monedas = 0;
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }

    public void UpdateScore()
    {
        monedas++;
        score.text = monedas.ToString();
    }

    public int getMonedas()
    {
        return monedas;
    }


}
