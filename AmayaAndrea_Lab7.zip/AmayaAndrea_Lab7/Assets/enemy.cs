﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.AI;

public class enemy : MonoBehaviour
{
    private NavMeshAgent agent;
    public Transform[] waypoints;
    private Boolean move = true;

    // Start is called before the first frame update
    void Start()
    {
        agent = GetComponent<NavMeshAgent>();
    }

    // Update is called once per frame
    void Update()
    {
        if (agent.remainingDistance < 0.05f)
        {
            if (move)
            {
                agent.SetDestination(waypoints[1].transform.position);
                move = false;
            } else
            {
                agent.SetDestination(waypoints[0].transform.position);
                move = true;
            }

        }

    }


}
    